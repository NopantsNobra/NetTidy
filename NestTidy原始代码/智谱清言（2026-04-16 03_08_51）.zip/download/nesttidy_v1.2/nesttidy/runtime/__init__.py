"""运行时模块：调度器、进度报告器、日志、配置等。"""
# 延迟导入以避免循环依赖
__all__ = [
    "setup_logging",
    "get_logger",
    "Config",
    "ConfigLoader",
    "load_config",
    "Scheduler",
    "TaskResult",
    "ProgressReporter",
    "MultiPhaseProgress",
    "ChangesWriter",
    "changes_writer",
]


def __getattr__(name):
    """延迟导入。"""
    if name == "setup_logging":
        from nesttidy.runtime.logger import setup_logging
        return setup_logging
    elif name == "get_logger":
        from nesttidy.runtime.logger import get_logger
        return get_logger
    elif name == "Config":
        from nesttidy.runtime.config import Config
        return Config
    elif name == "ConfigLoader":
        from nesttidy.runtime.config import ConfigLoader
        return ConfigLoader
    elif name == "load_config":
        from nesttidy.runtime.config import load_config
        return load_config
    elif name == "Scheduler":
        from nesttidy.runtime.scheduler import Scheduler
        return Scheduler
    elif name == "TaskResult":
        from nesttidy.runtime.scheduler import TaskResult
        return TaskResult
    elif name == "ProgressReporter":
        from nesttidy.runtime.progress import ProgressReporter
        return ProgressReporter
    elif name == "MultiPhaseProgress":
        from nesttidy.runtime.progress import MultiPhaseProgress
        return MultiPhaseProgress
    elif name == "ChangesWriter":
        from nesttidy.runtime.changes_writer import ChangesWriter
        return ChangesWriter
    elif name == "changes_writer":
        from nesttidy.runtime.changes_writer import changes_writer
        return changes_writer
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
