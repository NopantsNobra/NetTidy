"""增强功能模块：重复检测、差异报告、系统文件过滤等。"""
# 延迟导入以避免循环依赖
__all__ = [
    "DupDetector",
    "DiffGenerator",
    "SystemFilter",
    "system_filter",
]


def __getattr__(name):
    """延迟导入。"""
    if name == "DupDetector":
        from nesttidy.enhance.dup_detector import DupDetector
        return DupDetector
    elif name == "DiffGenerator":
        from nesttidy.enhance.diff_generator import DiffGenerator
        return DiffGenerator
    elif name == "SystemFilter":
        from nesttidy.enhance.system_filter import SystemFilter
        return SystemFilter
    elif name == "system_filter":
        from nesttidy.enhance.system_filter import system_filter
        return system_filter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
